import { Link, Head } from '@inertiajs/react';
import { useEffect, useRef, useState } from 'react';
import { clientLogos, testimonials, blogPosts, legalitasBadges, trainingSchedule } from '@/data/mockData';
import BrandLogo from '@/components/public/BrandLogos';
import CustomSelect from '@/components/public/CustomSelect';

export default function Home() {
    const statsRef = useRef<HTMLDivElement>(null);
    const [faqOpen, setFaqOpen] = useState<number | null>(null);
    const [formSubmitted, setFormSubmitted] = useState(false);
    const [selectedProgram, setSelectedProgram] = useState('');

    const toggleFaq = (index: number) => {
        setFaqOpen(faqOpen === index ? null : index);
    };

    useEffect(() => {
        // Scroll reveal
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) entry.target.classList.add('visible');
            });
        }, { threshold: 0.1 });
        document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

        // Animated counters
        const countUp = (el: HTMLElement, target: number, suffix: string) => {
            let current = 0;
            const increment = target / 60;
            const timer = setInterval(() => {
                current += increment;
                if (current >= target) { current = target; clearInterval(timer); }
                el.textContent = Math.floor(current).toLocaleString() + suffix;
            }, 20);
        };

        const statsObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.querySelectorAll('[data-count]').forEach((el) => {
                        const htmlEl = el as HTMLElement;
                        countUp(htmlEl, parseInt(htmlEl.dataset.count || '0'), htmlEl.dataset.suffix || '');
                    });
                    statsObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.3 });
        if (statsRef.current) statsObserver.observe(statsRef.current);

        return () => { observer.disconnect(); statsObserver.disconnect(); };
    }, []);

    return (
        <>
            <Head title="Pelatihan K3 & Sertifikasi BNSP Terpercaya │ ProSafe Indonesia">
                <meta name="description" content="Pusat pelatihan K3 dan sertifikasi BNSP terpercaya di Surabaya & Seluruh Indonesia. Pelatihan Kemnaker RI, BNSP, K3 Migas, Inhouse Training. Konsultasi gratis!" />
                <meta property="og:title" content="Pelatihan K3 & Sertifikasi BNSP Terpercaya │ ProSafe Indonesia" />
                <meta property="og:description" content="Pusat pelatihan K3 dan sertifikasi kompetensi K3 industri, maritime, offshore, and rescue terbaik untuk kesiapan tim dan kepatuhan perusahaan Anda." />
                <meta property="og:type" content="website" />
                <script type="application/ld+json">
                    {JSON.stringify({
                        "@context": "https://schema.org",
                        "@type": "Organization",
                        "name": "ProSafe Indonesia",
                        "url": "https://prosafe.co.id",
                        "logo": "https://prosafe.co.id/images/logo-prosafe.png",
                        "contactPoint": {
                            "@type": "ContactPoint",
                            "telephone": "+6281222998847",
                            "contactType": "customer service",
                            "areaServed": "ID",
                            "availableLanguage": "Indonesian"
                        },
                        "sameAs": [
                            "https://www.facebook.com/prosafeindonesia",
                            "https://www.instagram.com/prosafe_indonesia"
                        ]
                    })}
                </script>
                <script type="application/ld+json">
                    {JSON.stringify({
                        "@context": "https://schema.org",
                        "@type": "Product",
                        "name": "Pelatihan K3 & Sertifikasi BNSP",
                        "image": "https://prosafe.co.id/images/logo-prosafe.png",
                        "description": "Pelatihan Keselamatan dan Kesehatan Kerja (K3) resmi Kemnaker RI dan sertifikasi BNSP.",
                        "aggregateRating": {
                            "@type": "AggregateRating",
                            "ratingValue": "4.9",
                            "reviewCount": "582"
                        }
                    })}
                </script>
            </Head>

            {/* Hero Section */}
            <section className="relative min-h-[600px] lg:min-h-[680px] xl:min-h-[720px] flex items-center overflow-hidden bg-deep-navy">
                {/* Background Image with Cover and Alignment */}
                <div className="absolute inset-0 bg-cover bg-center lg:bg-[center_right_20%] z-0" style={{ backgroundImage: "url('/images/hero-bg.jpg')" }} />
                
                {/* Gradient Overlay for Text Readability */}
                <div className="absolute inset-0 bg-gradient-to-b lg:bg-gradient-to-r from-deep-navy via-deep-navy/95 lg:via-deep-navy/80 to-deep-navy/15 z-10" />
                
                {/* Dynamic Radial Glow in top left corner */}
                <div className="absolute top-0 left-0 w-[450px] h-[450px] bg-safety-orange/10 rounded-full blur-[120px] pointer-events-none z-10" />
                
                {/* Grid Overlay inside the Hero */}
                <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff03_1px,transparent_1px),linear-gradient(to_bottom,#ffffff03_1px,transparent_1px)] bg-[size:36px_36px] pointer-events-none z-10 opacity-60" />

                {/* Content Container */}
                <div className="relative px-6 py-20 lg:py-28 max-w-[1280px] mx-auto w-full z-20">
                    <div className="max-w-2xl lg:max-w-[650px] space-y-6">
                        {/* Premium Badge */}
                        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-white/10 border border-white/15 rounded-full backdrop-blur-md shadow-sm">
                            <span className="relative flex h-2 w-2">
                                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-safety-orange opacity-75"></span>
                                <span className="relative inline-flex rounded-full h-2 w-2 bg-safety-orange"></span>
                            </span>
                            <span className="text-xs font-heading font-black text-safety-orange uppercase tracking-wider">
                                Pusat Pelatihan K3 & Rescue Resmi
                            </span>
                        </div>
                        
                        {/* Premium Headline */}
                        <h1 className="font-heading text-[34px] sm:text-5xl lg:text-6xl font-black text-white leading-[1.15] sm:leading-[1.1] tracking-tight">
                            Pelatihan K3 & <span className="text-safety-orange">Emergency Response</span> Bersertifikasi
                        </h1>
                        
                        {/* Description */}
                        <p className="text-sm sm:text-base md:text-lg text-slate-200 leading-relaxed max-w-xl">
                            Penyedia jasa safety training dan sertifikasi kompetensi K3 industri, maritime, offshore, dan rescue terbaik untuk kesiapan tim dan kepatuhan perusahaan Anda. Surabaya & Seluruh Indonesia.
                        </p>
                        
                        {/* Action Buttons */}
                        <div className="flex flex-col sm:flex-row gap-4 pt-2">
                            <a href="https://wa.me/6281222998847" className="bg-safety-orange text-white font-heading font-bold px-8 py-4 rounded-xl text-center hover:bg-safety-orange/90 shadow-md hover:shadow-xl hover:shadow-safety-orange/20 flex items-center justify-center gap-3 transition-all duration-300 active:scale-[0.98] group">
                                <svg fill="currentColor" viewBox="0 0 16 16" className="w-5.5 h-5.5 shrink-0 group-hover:rotate-12 transition-transform" xmlns="http://www.w3.org/2000/svg" style={{ width: '22px', height: '22px' }}>
                                    <path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.57 6.57 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z"/>
                                </svg>
                                <span>Konsultasi via WhatsApp</span>
                            </a>
                            <Link href="/pelatihan/kemnaker" className="border-2 border-white/20 text-white font-heading font-bold px-8 py-4 rounded-xl text-center hover:bg-white hover:text-deep-navy transition-all duration-300 active:scale-[0.98]">
                                Lihat Program Training
                            </Link>
                        </div>
                        
                        {/* Premium Accreditations (styled for dark background) */}
                        <div className="pt-6 flex flex-wrap items-center gap-4">
                            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Terakreditasi & Resmi:</span>
                            <div className="flex flex-wrap gap-3">
                                {[
                                    { label: 'Kemnaker RI', image: '/images/badges/kemnaker.png' },
                                    { label: 'BNSP', image: '/images/badges/bnsp.png' },
                                    { label: 'ISO 9001:2015', image: '/images/badges/iso9001.svg' }
                                ].map((badge, idx) => (
                                    <div key={idx} className="h-10 px-4 flex items-center justify-center bg-white rounded-xl shadow-md transition-transform duration-300 hover:scale-110 cursor-pointer" title={badge.label}>
                                        <img src={badge.image} alt={badge.label} className="h-7 w-auto object-contain" />
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Highlights Banner */}
            <section className="bg-surface-gray py-6 sm:py-8 border-y border-outline-variant/60">
                <div className="max-w-[1280px] mx-auto px-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
                    {[
                        { icon: 'domain', text: 'In-house & On-Site Training' },
                        { icon: 'workspace_premium', text: 'Sertifikat Peserta' },
                        { icon: 'psychology', text: 'Berbasis Praktik Nyata' },
                        { icon: 'groups', text: 'Instruktur Berpengalaman' }
                    ].map((item, idx) => (
                        <div key={idx} className="flex flex-row items-center gap-3.5 px-4 py-3.5 sm:p-0 bg-white sm:bg-transparent rounded-xl border border-outline-variant/30 sm:border-none shadow-sm sm:shadow-none">
                            <div className="w-10 h-10 sm:w-auto sm:h-auto rounded-lg bg-safety-orange/10 sm:bg-transparent flex items-center justify-center shrink-0">
                                <span className="material-symbols-outlined text-safety-orange text-[22px] sm:text-3xl shrink-0">{item.icon}</span>
                            </div>
                            <span className="font-heading font-semibold text-deep-navy text-sm leading-snug">{item.text}</span>
                        </div>
                    ))}
                </div>
            </section>

            {/* Stats Section */}
            <section ref={statsRef} className="py-12 border-b border-outline-variant bg-white px-6">
                <div className="max-w-[1280px] mx-auto grid grid-cols-2 md:grid-cols-4 gap-8">
                    {[
                        { value: 15000, suffix: '+', label: 'Alumni Sertifikasi' },
                        { value: 500, suffix: '+', label: 'Klien Korporat' },
                        { value: 50, suffix: '+', label: 'Program Pelatihan' },
                        { value: 49, suffix: '/5', label: 'Rating Peserta' },
                    ].map((stat, i) => (
                        <div key={i} className="text-center md:text-left md:pl-8 md:border-l md:first:border-l-0 border-outline-variant/50 stat-counter rounded-lg p-2">
                            <p className="font-heading text-3xl md:text-4xl font-bold text-deep-navy">
                                <span data-count={stat.value === 49 ? '4' : stat.value} data-suffix={stat.value === 49 ? '.9/5' : stat.suffix}>0</span>
                            </p>
                            <p className="text-sm text-on-surface-variant mt-2 font-medium">{stat.label}</p>
                        </div>
                    ))}
                </div>
            </section>

            {/* About Brief */}
            <section className="py-12 md:py-24 px-6 max-w-[1280px] mx-auto reveal">
                <div className="grid md:grid-cols-2 gap-10 lg:gap-16 items-center">
                    {/* Image — layered floating frame */}
                    <div className="relative">
                        {/* Background accent shape */}
                        <div className="absolute -inset-3 md:-inset-4 bg-safety-orange/[0.06] rounded-3xl -rotate-2" />
                        <div className="relative rounded-2xl overflow-hidden shadow-xl shadow-deep-navy/10">
                            <img alt="Sesi pelatihan K3 di pusat training ProSafe Indonesia" className="w-full h-[360px] md:h-[420px] object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAqyKcQY9gpntiRfAOpKbsV-wa2c67lnRTK6Ej7Rg2MKZqO1HJFU4F5LFpULQ5rcWj4XjDY-JqTjMKKbjShoDr3bP-XN2Omi92EQfxJrhL1Zb5zBU1wCml69VtsinDLo1_NM9PvWjv9KQc3Kam-GkQ_r5LrgAf0JvAiYExrOWLHXHHKGvHQ3jGSMbOO29MaXPqqh0jCV9MxAY96v38wN7zbfIKAW-b9VfW3R_wctwp51-tOOWRbE_U3XmfdqhSULkVa2l4fs7uALP49" />
                        </div>
                    </div>

                    {/* Text content */}
                    <div className="space-y-5">
                        <p className="text-safety-orange font-heading font-bold text-xs uppercase tracking-[0.2em]">Tentang Kami</p>
                        <h2 className="font-heading text-2xl md:text-3xl lg:text-[2.1rem] font-bold text-deep-navy leading-snug" style={{ textWrap: 'balance' } as React.CSSProperties}>
                            Tentang Pro Safe Indonesia
                        </h2>
                        <p className="text-base text-on-surface-variant leading-relaxed">
                            ProSafe Indonesia didirikan dengan misi untuk membantu organisasi dan tenaga profesional di seluruh Indonesia membangun standar keselamatan kerja (K3) tertinggi melalui pelatihan bersertifikasi resmi, simulasi berbasis praktik nyata, dan pendampingan implementasi keselamatan kerja komprehensif.
                        </p>
                        <ul className="space-y-3 pt-1">
                            {[
                                { title: 'Instruktur Tersertifikasi', desc: 'Praktisi berpengalaman dengan lisensi resmi.' },
                                { title: 'Fasilitas Modern', desc: 'Pusat pelatihan dilengkapi simulasi praktik standar industri.' },
                            ].map(item => (
                                <li key={item.title} className="flex items-start gap-3.5 bg-surface-gray rounded-xl px-4 py-3.5 border border-outline-variant/40">
                                    <span className="material-symbols-outlined icon-fill text-safety-orange text-xl mt-0.5 shrink-0">check_circle</span>
                                    <div>
                                        <h4 className="font-heading font-bold text-deep-navy text-[15px] leading-snug">{item.title}</h4>
                                        <p className="text-xs text-on-surface-variant mt-0.5 leading-relaxed">{item.desc}</p>
                                    </div>
                                </li>
                            ))}
                        </ul>
                        <div className="pt-2">
                            <Link href="/tentang-kami" className="arrow-link link-underline text-deep-navy font-heading font-semibold hover:text-safety-orange inline-flex items-center gap-1">
                                Pelajari Lebih Lanjut <span className="material-symbols-outlined">arrow_forward</span>
                            </Link>
                        </div>
                    </div>
                </div>
            </section>

            {/* Layanan Unggulan */}
            <section className="py-12 md:py-20 px-6 max-w-[1280px] mx-auto reveal">
                <div className="text-center max-w-3xl mx-auto mb-8 md:mb-16">
                    <p className="text-safety-orange font-heading font-bold text-xs uppercase tracking-[0.2em] mb-2">Layanan Kami</p>
                    <h2 className="font-heading text-2xl md:text-3xl lg:text-[2.1rem] font-bold text-deep-navy mb-3">Layanan Unggulan ProSafe</h2>
                    <div className="section-divider" />
                    <p className="text-base text-on-surface-variant mt-3">Solusi komprehensif keselamatan kerja (K3) untuk kesiapan operasional dan kepatuhan hukum perusahaan Anda.</p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {[
                        {
                            icon: 'shield_person',
                            title: 'Pelatihan Kemnaker RI',
                            desc: 'Sertifikasi K3 resmi penunjukan Kementerian Ketenagakerjaan RI untuk legalitas perusahaan.',
                            href: '/pelatihan/kemnaker'
                        },
                        {
                            icon: 'workspace_premium',
                            title: 'Sertifikasi BNSP',
                            desc: 'Sertifikasi kompetensi profesi K3 skala nasional berlisensi Badan Nasional Sertifikasi Profesi.',
                            href: '/pelatihan/bnsp'
                        },
                        {
                            icon: 'local_fire_department',
                            title: 'K3 Migas & Offshore',
                            desc: 'Pelatihan keselamatan khusus sektor minyak, gas bumi, maritim, dan lepas pantai.',
                            href: '/pelatihan/migas'
                        },
                        {
                            icon: 'menu_book',
                            title: 'Non-Sertifikasi',
                            desc: 'Pelatihan teknis spesifik & awareness internal untuk memperkuat kompetensi K3 tim Anda.',
                            href: '/pelatihan/non-sertifikasi'
                        },
                        {
                            icon: 'domain',
                            title: 'Corporate In-House',
                            desc: 'Penyelenggaraan safety training kustom langsung di lokasi operasional perusahaan Anda.',
                            href: '/corporate'
                        },
                        {
                            icon: 'analytics',
                            title: 'Consulting K3 & Audit',
                            desc: 'Pendampingan penyusunan dokumen SMK3, HIRADC, CSMS, dan persiapan audit eksternal.',
                            href: '/corporate'
                        },
                        {
                            icon: 'fact_check',
                            title: 'ISO Consulting',
                            desc: 'Konsultasi sertifikasi sistem manajemen ISO 9001, ISO 14001, dan ISO 45001.',
                            href: '/corporate'
                        },
                        {
                            icon: 'emergency',
                            title: 'Emergency & Rescue',
                            desc: 'Pelatihan khusus tim pemadam kebakaran, penyelamat ketinggian, dan ruang terbatas.',
                            href: '/pelatihan/non-sertifikasi'
                        }
                    ].map((item, idx) => (
                        <Link 
                            key={idx} 
                            href={item.href}
                            className="group block bg-white border border-outline-variant hover:border-safety-orange hover:shadow-lg rounded-2xl p-6 transition-all duration-300 active:scale-[0.98] relative overflow-hidden"
                        >
                            <div className="absolute top-0 right-0 w-24 h-24 bg-safety-orange/[0.02] rounded-full translate-x-8 -translate-y-8 group-hover:scale-150 transition-transform duration-500" />
                            <div className="w-12 h-12 rounded-xl bg-safety-orange/10 flex items-center justify-center mb-5 text-safety-orange group-hover:bg-safety-orange group-hover:text-white transition-colors duration-300 shadow-inner">
                                <span className="material-symbols-outlined text-2xl">{item.icon}</span>
                            </div>
                            <h3 className="font-heading text-base font-bold text-deep-navy mb-2 group-hover:text-safety-orange transition-colors">
                                {item.title}
                            </h3>
                            <p className="text-xs text-on-surface-variant leading-relaxed mb-4">
                                {item.desc}
                            </p>
                            <span className="inline-flex items-center text-safety-orange font-heading text-[11px] font-bold uppercase tracking-wider group-hover:translate-x-1 transition-transform duration-300">
                                Selengkapnya <span className="material-symbols-outlined text-xs ml-1 font-bold">arrow_forward</span>
                            </span>
                        </Link>
                    ))}
                </div>
            </section>

            {/* Featured Programs */}
            <section className="py-12 md:py-20 px-6 bg-surface-gray border-y border-outline-variant reveal">
                <div className="max-w-[1280px] mx-auto">
                    <div className="text-center max-w-3xl mx-auto mb-6 md:mb-12">
                        <h2 className="font-heading text-2xl md:text-3xl font-bold text-deep-navy mb-3">Program Unggulan Kami</h2>
                        <div className="section-divider" />
                        <p className="text-lg text-on-surface-variant">Program pelatihan K3 dasar yang paling dibutuhkan di berbagai sektor industri.</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {[
                            {
                                image: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=800&q=80',
                                badge: 'KEMNAKER & BNSP',
                                title: 'Basic First Aid (BFA)',
                                quote: 'Pertolongan pertama cepat & tepat pada kecelakaan kerja.',
                                highlights: [
                                    'Sertifikasi Resmi Kemnaker / BNSP',
                                    'Praktik RJP (CPR) & Balut Bidai',
                                    'Penanganan Luka & Cedera Darurat'
                                ],
                                href: '/program/petugas-p3k'
                            },
                            {
                                image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCMMy4zd_h2un2qwm9jz4YTJTASi7mJGlgTkD8Sw2Yp2y9dQnDNdRUX9C_SO1shj136hG8wMybMlmfmAtNslHa75LRLfHn4BLsbfCyAC3d7FupTw_JMyC1GmAAglkJmuQyxjm0FV84MGNvmCOxNO_3KcIW0C80DVyn2D8vW1H1gAR_TzcCoS-4aekpjRtzUwdQdasmCFAbX-7ISaOr-ZMctWArVI4TK7xh2l43v0t7LlHl0NqGbJsbdX8RMEw4AQzLuIh13WXi3P4ll',
                                badge: 'KEMNAKER',
                                title: 'Basic Fire Fighting (BFF)',
                                quote: 'Penanggulangan kebakaran dini dengan taktis dan aman.',
                                highlights: [
                                    'Sertifikasi Peran Kebakaran Kelas D',
                                    'Simulasi APAR & Fire Hose Praktis',
                                    'Prosedur Evakuasi Darurat Gedung'
                                ],
                                href: '/program/petugas-peran-kebakaran'
                            },
                            {
                                image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAt_LezpZvBlUQJnh_aglc-ALGkFFTe4Jox0pmmkokNKUYcBh4vCIE1QM2PG5lgRFaiChPir2uKHt_lQbVvLIHjD0fMMnGubQ-HIdCsrkaGYDu3HDDhpA_XYchJEDSu0mGBGup_fKp62cUW0enYHofRhSK6xdT3QSGe9EKrAlPsQiJ_bwg39R9Tdqst4K6jEVGDCFOLmJoaOMGtTp_-_wRV9ORGE2qJTbWRtEwKQWgL-AIIlbgWEr6iziCH4Avi6d9OMuN6A5V-RUkE',
                                badge: 'KEMNAKER & BNSP',
                                title: 'Safety Awareness (BBS)',
                                quote: 'Membangun budaya keselamatan kerja yang proaktif.',
                                highlights: [
                                    'Sertifikasi Ahli K3 Umum Kemnaker',
                                    'Behavior Based Safety (BBS)',
                                    'Identifikasi Bahaya (HIRADC)'
                                ],
                                href: '/program/ahli-k3-umum'
                            }
                        ].map((card, i) => (
                            <Link key={i} href={card.href} className="group block bg-white rounded-2xl border border-outline-variant hover:border-deep-navy hover:shadow-lg transition-all relative overflow-hidden flex flex-col h-full">
                                <div className="absolute top-0 left-0 w-full h-1 bg-safety-orange origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-300 z-10" />
                                <div className="relative h-48 overflow-hidden bg-slate-100">
                                    <img src={card.image} alt={card.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                                    <div className="absolute top-4 left-4 bg-deep-navy/80 backdrop-blur-md text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider border border-white/20">
                                        {card.badge}
                                    </div>
                                </div>
                                <div className="p-6 flex flex-col flex-grow">
                                    <h3 className="font-heading text-lg font-bold text-deep-navy mb-2 group-hover:text-safety-orange transition-colors">{card.title}</h3>
                                    <p className="text-xs text-text-secondary italic mb-4">"{card.quote}"</p>
                                    <ul className="space-y-2 mb-6 flex-grow">
                                        {card.highlights.map((highlight, idx) => (
                                            <li key={idx} className="flex items-start gap-2 text-xs text-on-surface-variant">
                                                <span className="material-symbols-outlined text-safety-orange text-sm shrink-0 mt-0.5">check_circle</span>
                                                <span>{highlight}</span>
                                            </li>
                                        ))}
                                    </ul>
                                    <div className="pt-4 border-t border-outline-variant/60 flex items-center justify-between">
                                        <span className="inline-flex items-center text-safety-orange text-xs font-bold uppercase tracking-wider">
                                            Lihat Detail Program <span className="material-symbols-outlined text-sm ml-1 group-hover:translate-x-1.5 transition-transform duration-200">arrow_forward</span>
                                        </span>
                                    </div>
                                </div>
                            </Link>
                        ))}
                    </div>
                </div>
            </section>

            {/* Maritime & Offshore specialized */}
            <section className="py-12 md:py-20 px-6 max-w-[1280px] mx-auto reveal">
                <div className="text-center max-w-3xl mx-auto mb-6 md:mb-12">
                    <h2 className="font-heading text-2xl md:text-3xl font-bold text-deep-navy mb-3">Program Khusus Maritime & Offshore</h2>
                    <div className="section-divider" />
                    <p className="text-lg text-on-surface-variant">Pelatihan spesialisasi keselamatan laut dan lepas pantai dengan standar industri global.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                    {[
                        {
                            image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=800&q=80',
                            badge: 'MARITIME SAFETY',
                            title: 'Basic Sea Survival & HUET',
                            quote: 'Kemampuan bertahan hidup darurat di perairan terbuka.',
                            highlights: [
                                'Teori & Simulasi Sea Survival Lengkap',
                                'Helicopter Underwater Escape Training (HUET)',
                                'Penyelamatan diri menggunakan Liferaft'
                            ],
                            href: '/program/bosiet-sea-survival'
                        },
                        {
                            image: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=800&q=80',
                            badge: 'OFFSHORE SAFETY',
                            title: 'BOSIET',
                            quote: 'Sertifikasi keselamatan wajib pekerja rig offshore.',
                            highlights: [
                                'Basic Offshore Safety Induction',
                                'Fire Fighting & Self Rescue Training',
                                'HUET & First Aid Competency'
                            ],
                            href: '/program/bosiet-sea-survival'
                        }
                    ].map((card, i) => (
                        <Link key={i} href={card.href} className="group block bg-white rounded-2xl border border-outline-variant hover:border-deep-navy hover:shadow-lg transition-all relative overflow-hidden flex flex-col h-full">
                            <div className="absolute top-0 left-0 w-full h-1 bg-deep-navy origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-300 z-10" />
                            <div className="relative h-48 overflow-hidden bg-slate-100">
                                <img src={card.image} alt={card.title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                                <div className="absolute top-4 left-4 bg-deep-navy/80 backdrop-blur-md text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider border border-white/20">
                                    {card.badge}
                                </div>
                            </div>
                            <div className="p-6 flex flex-col flex-grow">
                                <h3 className="font-heading text-lg font-bold text-deep-navy mb-2 group-hover:text-safety-orange transition-colors">{card.title}</h3>
                                <p className="text-xs text-text-secondary italic mb-4">"{card.quote}"</p>
                                <ul className="space-y-2 mb-6 flex-grow">
                                    {card.highlights.map((highlight, idx) => (
                                        <li key={idx} className="flex items-start gap-2 text-xs text-on-surface-variant">
                                            <span className="material-symbols-outlined text-safety-orange text-sm shrink-0 mt-0.5">check_circle</span>
                                            <span>{highlight}</span>
                                        </li>
                                    ))}
                                </ul>
                                <div className="pt-4 border-t border-outline-variant/60 flex items-center justify-between">
                                    <span className="inline-flex items-center text-deep-navy text-xs font-bold uppercase tracking-wider group-hover:text-safety-orange transition-colors">
                                        Selengkapnya <span className="material-symbols-outlined text-sm ml-1 group-hover:translate-x-1.5 transition-transform duration-200">arrow_forward</span>
                                    </span>
                                </div>
                            </div>
                        </Link>
                    ))}
                </div>
            </section>

            {/* Jadwal Training Terbaru */}
            <section className="py-12 md:py-20 px-6 max-w-[1000px] mx-auto reveal">
                <div className="text-center max-w-3xl mx-auto mb-6 md:mb-12">
                    <h2 className="font-heading text-3xl md:text-4xl font-extrabold text-deep-navy mb-2">
                        Jadwal Pelatihan <span className="text-safety-orange">Juli & Agustus</span>
                    </h2>
                    <p className="font-heading text-lg md:text-xl font-black text-deep-navy/85 uppercase tracking-wider">
                        BNSP, KEMNAKER RI, MIGAS
                    </p>
                </div>

                <div className="space-y-12">
                    {[
                        { 
                            title: 'Pelatihan dan Pembinaan KEMNAKER RI', 
                            items: trainingSchedule.filter(s => s.category === 'KEMNAKER') 
                        },
                        { 
                            title: 'Pelatihan dan Sertifikasi BNSP', 
                            items: trainingSchedule.filter(s => s.category === 'BNSP') 
                        },
                        { 
                            title: 'Pelatihan K3 Migas & Offshore', 
                            items: trainingSchedule.filter(s => s.category === 'MIGAS') 
                        }
                    ].map((group, groupIdx) => (
                        <div key={groupIdx} className="space-y-3">
                            <h3 className="font-heading text-lg md:text-xl font-bold text-deep-navy border-b border-outline-variant/60 pb-2">
                                {group.title}
                            </h3>
                            <div className="overflow-x-auto rounded-xl border border-outline-variant shadow-sm">
                                <table className="w-full text-left border-collapse">
                                    <thead>
                                        <tr className="bg-deep-navy text-white text-xs md:text-sm font-bold font-heading">
                                            <th className="py-3 px-4 md:px-6 w-[50%]">Skema</th>
                                            <th className="py-3 px-4 md:px-6 w-[25%]">Jadwal</th>
                                            <th className="py-3 px-4 md:px-6 w-[25%]">Pelaksanaan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {group.items.map((sch, itemIdx) => (
                                            <tr 
                                                key={sch.id}
                                                onClick={() => {
                                                    window.open(`https://wa.me/6281222998847?text=Halo%20Admin,%20saya%20tertarik%20mendaftar%20kelas%20${encodeURIComponent(sch.program)}%20jadwal%20${encodeURIComponent(sch.date)}.`, '_blank');
                                                }}
                                                className={`text-xs md:text-sm text-deep-navy cursor-pointer hover:bg-safety-orange/5 transition-colors border-b border-outline-variant/50 last:border-b-0 ${
                                                    itemIdx % 2 === 1 ? 'bg-surface-gray' : 'bg-white'
                                                }`}
                                            >
                                                <td className="py-3.5 px-4 md:px-6 font-semibold flex items-center gap-2.5">
                                                    <span className="material-symbols-outlined icon-fill text-safety-orange text-base md:text-lg shrink-0">check_circle</span>
                                                    <span>{sch.program}</span>
                                                </td>
                                                <td className="py-3.5 px-4 md:px-6 text-on-surface-variant">
                                                    {sch.date}
                                                </td>
                                                <td className="py-3.5 px-4 md:px-6 italic text-on-surface-variant font-medium">
                                                    {sch.method}
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    ))}
                </div>

                <div className="mt-12 text-center">
                    <Link href="/jadwal" className="btn-prosafe-secondary inline-flex items-center gap-2 text-sm px-8 py-3.5 shadow-sm">
                        <span className="material-symbols-outlined text-sm">calendar_month</span> Lihat Semua Jadwal Training
                    </Link>
                </div>
            </section>

            {/* Mengapa Memilih Kami */}
            <section className="py-12 md:py-20 px-6 bg-surface-gray border-y border-outline-variant reveal">
                <div className="max-w-[1280px] mx-auto">
                    <div className="text-center max-w-3xl mx-auto mb-6 md:mb-12">
                        <h2 className="font-heading text-2xl md:text-3xl font-bold text-deep-navy mb-3">Mengapa Memilih Pro Safe Indonesia</h2>
                        <div className="section-divider" />
                        <p className="text-lg text-on-surface-variant">Layanan safety training prima dengan komitmen kepuasan dan kualitas sertifikasi terbaik.</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                        {[
                            { icon: 'menu_book', title: 'Materi Praktis & Relevan', desc: 'Kurikulum disesuaikan dengan kebutuhan nyata industri modern dan regulasi K3 terkini.' },
                            { icon: 'school', title: 'Instruktur Bersertifikasi', desc: 'Dipandu oleh praktisi K3 dan rescue ahli dengan jam terbang mengajar yang tinggi.' },
                            { icon: 'calendar_month', title: 'Jadwal Fleksibel', desc: 'Kami menawarkan jadwal pelatihan yang dapat disesuaikan dengan operasional perusahaan Anda.' },
                            { icon: 'verified', title: 'Sertifikat Resmi', desc: 'Sertifikat resmi yang diakui secara nasional oleh KEMNAKER RI dan BNSP.' },
                            { icon: 'home_repair_service', title: 'Fasilitas Lengkap', desc: 'Pusat pelatihan modern dengan alat peraga dan simulator simulasi praktis terbaik.' },
                            { icon: 'support_agent', title: 'Dukungan Pasca Pelatihan', desc: 'Pendampingan konsultasi K3 berkelanjutan bagi perusahaan alumni peserta kami.' }
                        ].map((card, i) => (
                            <div key={i} className="bg-white rounded-2xl p-6 border border-outline-variant shadow-sm hover:shadow-md transition-shadow">
                                <div className="w-12 h-12 rounded-xl bg-safety-orange/10 flex items-center justify-center mb-4 text-safety-orange">
                                    <span className="material-symbols-outlined text-2xl">{card.icon}</span>
                                </div>
                                <h3 className="font-heading text-lg font-bold text-deep-navy mb-2">{card.title}</h3>
                                <p className="text-sm text-on-surface-variant leading-relaxed">{card.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Target Peserta */}
            <section className="py-12 md:py-20 px-6 max-w-[1280px] mx-auto reveal">
                <div className="text-center max-w-3xl mx-auto mb-6 md:mb-12">
                    <h2 className="font-heading text-2xl md:text-3xl font-bold text-deep-navy mb-3">Industri Target & Peserta</h2>
                    <div className="section-divider" />
                    <p className="text-lg text-on-surface-variant">Layanan kami dirancang untuk membekali tenaga kerja di berbagai sektor berisiko tinggi.</p>
                </div>
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
                    {[
                        {
                            label: 'Minyak & Gas',
                            desc: 'K3 operasional rig, refinery & distribusi migas.',
                            image: 'https://images.unsplash.com/photo-1513828583688-c52646db42da?auto=format&fit=crop&w=600&q=80',
                            tags: ['Migas', 'Offshore'],
                            tintFrom: 'rgba(40,35,20,0.92)',
                        },
                        {
                            label: 'Manufaktur',
                            desc: 'Sertifikasi keselamatan lini produksi & pabrik.',
                            image: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=600&q=80',
                            tags: ['Pabrik', 'Produksi'],
                            tintFrom: 'rgba(25,35,50,0.92)',
                        },
                        {
                            label: 'Konstruksi',
                            desc: 'Standar K3 proyek bangunan & infrastruktur.',
                            image: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?auto=format&fit=crop&w=600&q=80',
                            tags: ['Proyek', 'Infrastruktur'],
                            tintFrom: 'rgba(45,40,25,0.92)',
                        },
                        {
                            label: 'Pertambangan',
                            desc: 'K3 tambang mineral, batu bara & nikel.',
                            image: 'https://images.unsplash.com/photo-1580058572462-98e2c0e0e2f0?auto=format&fit=crop&w=600&q=80',
                            tags: ['Mineral', 'Batu Bara'],
                            tintFrom: 'rgba(40,35,25,0.92)',
                        },
                        {
                            label: 'Maritim',
                            desc: 'Keselamatan laut, HUET & offshore safety.',
                            image: 'https://images.unsplash.com/photo-1494412574643-ff11b0a5c1c3?auto=format&fit=crop&w=600&q=80',
                            tags: ['Perkapalan', 'Offshore'],
                            tintFrom: 'rgba(15,30,50,0.92)',
                        },
                        {
                            label: 'Perhotelan',
                            desc: 'Pelatihan kebakaran, evakuasi & P3K hotel.',
                            image: 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=600&q=80',
                            tags: ['Pariwisata', 'Hotel'],
                            tintFrom: 'rgba(25,35,30,0.92)',
                        },
                        {
                            label: 'Kesehatan',
                            desc: 'Sertifikasi P3K & keselamatan fasilitas medis.',
                            image: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=600&q=80',
                            tags: ['Rumah Sakit', 'Medis'],
                            tintFrom: 'rgba(20,35,40,0.92)',
                        },
                        {
                            label: 'Pendidikan',
                            desc: 'Kesiapsiagaan bencana & K3 lembaga akademik.',
                            image: 'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=600&q=80',
                            tags: ['Universitas', 'Sekolah'],
                            tintFrom: 'rgba(30,25,20,0.92)',
                        },
                    ].map((item, i) => (
                        <div
                            key={i}
                            className="industry-card group relative rounded-2xl overflow-hidden flex flex-col cursor-default"
                            style={{ background: item.tintFrom }}
                        >
                            {/* Hero Image */}
                            <div className="relative aspect-[4/3] overflow-hidden shrink-0">
                                <img
                                    src={item.image}
                                    alt={item.label}
                                    className="w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                                    loading="lazy"
                                />
                                {/* Gradient fade */}
                                <div
                                    className="absolute inset-0"
                                    style={{
                                        background: `linear-gradient(to bottom, transparent 40%, ${item.tintFrom} 100%)`,
                                    }}
                                />
                            </div>

                            {/* Content */}
                            <div className="relative flex flex-col flex-grow px-4 sm:px-5 pb-4 sm:pb-5 -mt-3 z-10">
                                <h3 className="font-heading font-bold text-white text-sm sm:text-base leading-snug mb-1">
                                    {item.label}
                                </h3>
                                <p className="text-[11px] sm:text-xs text-white/55 leading-relaxed mb-3 line-clamp-2">
                                    {item.desc}
                                </p>
                                <div className="flex flex-wrap gap-1.5 mt-auto">
                                    {item.tags.map((tag, idx) => (
                                        <span
                                            key={idx}
                                            className="text-[10px] sm:text-[11px] font-semibold text-white/65 bg-white/10 px-2.5 py-1 rounded-full border border-white/[0.08]"
                                        >
                                            {tag}
                                        </span>
                                    ))}
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Alur Pelaksanaan */}
            <section className="py-12 md:py-20 px-6 bg-surface-gray border-y border-outline-variant reveal">
                <div className="max-w-[1280px] mx-auto">
                    <div className="text-center max-w-3xl mx-auto mb-8 md:mb-16">
                        <h2 className="font-heading text-2xl md:text-3xl font-bold text-deep-navy mb-3">Alur Pelaksanaan Training</h2>
                        <div className="section-divider" />
                        <p className="text-lg text-on-surface-variant">Tahapan profesional untuk memastikan pelatihan berjalan lancar dan berdaya guna.</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-8 relative">
                        {[
                            { step: '1', title: 'Konsultasi Kebutuhan', desc: 'Diskusi awal mengenai program pelatihan yang paling relevan dengan kondisi tempat kerja.' },
                            { step: '2', title: 'Penawaran & Custom', desc: 'Penyusunan penawaran resmi serta kustomisasi silabus materi agar sesuai profil industri.' },
                            { step: '3', title: 'Pelaksanaan Training', desc: 'Penyampaian materi teori interaktif serta simulasi praktik langsung di lapangan.' },
                            { step: '4', title: 'Evaluasi & Sertifikat', desc: 'Ujian kompetensi peserta, evaluasi trainer, dan penerbitan sertifikasi resmi.' }
                        ].map((item, i) => (
                            <div key={i} className="bg-white rounded-2xl p-6 border border-outline-variant relative pt-10 shadow-sm">
                                <div className="absolute -top-6 left-6 w-12 h-12 bg-safety-orange text-white font-heading font-black text-xl rounded-xl flex items-center justify-center shadow-md shadow-safety-orange/20">
                                    {item.step}
                                </div>
                                <h3 className="font-heading text-lg font-bold text-deep-navy mb-2 mt-1">{item.title}</h3>
                                <p className="text-xs text-on-surface-variant leading-relaxed">{item.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Client Logos - Infinite Carousel */}
            <section className="py-10 md:py-16 px-6 bg-white border-b border-outline-variant reveal">
                <div className="max-w-[1280px] mx-auto text-center">
                    <p className="text-xs font-bold text-text-secondary uppercase tracking-wider mb-8">Dipercaya oleh 500+ Perusahaan Terkemuka di Indonesia</p>
                    <div className="overflow-hidden relative py-4 -my-4">
                        <div className="logo-marquee flex gap-8 py-2">
                            {[...clientLogos, ...clientLogos].map((logo, i) => (
                                <div key={`${logo.name}-${i}`} className="logo-grayscale shrink-0 w-36 h-16 bg-white border border-outline-variant rounded-lg flex items-center justify-center p-3" title={logo.name}>
                                    <BrandLogo name={logo.name} className="max-h-full max-w-full" />
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </section>

            {/* Legalitas & Sertifikasi */}
            <section className="py-10 md:py-16 px-6 bg-surface-gray border-y border-outline-variant reveal">
                <div className="max-w-[1280px] mx-auto">
                    <div className="text-center max-w-3xl mx-auto mb-6 md:mb-12">
                        <p className="text-safety-orange font-heading font-bold text-xs uppercase tracking-[0.2em] mb-2">Legalitas & Sertifikasi</p>
                        <h2 className="font-heading text-2xl md:text-3xl font-bold text-deep-navy mb-3">Akreditasi & Izin Resmi</h2>
                        <div className="section-divider" />
                        <p className="text-sm text-on-surface-variant mt-3">ProSafe Indonesia adalah lembaga pelatihan K3 berlisensi resmi yang diakui secara nasional.</p>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                        {legalitasBadges.map((badge, idx) => (
                            <div key={idx} className="bg-white border border-outline-variant hover:border-safety-orange hover:shadow-md rounded-2xl p-6 transition-all duration-300 flex flex-col items-center text-center group">
                                <div className="w-full h-20 flex items-center justify-center mb-6 p-2 bg-surface-gray/50 rounded-xl group-hover:bg-white transition-colors duration-300">
                                    <img 
                                        src={badge.image} 
                                        alt={badge.title} 
                                        className="max-h-full max-w-full object-contain group-hover:scale-110 transition-transform duration-300 filter drop-shadow-sm" 
                                    />
                                </div>
                                <h3 className="font-heading font-bold text-base text-deep-navy mb-2">
                                    {badge.title}
                                </h3>
                                <p className="text-xs text-on-surface-variant leading-relaxed">
                                    {badge.desc}
                                </p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* FAQ Section */}
            <section className="py-12 md:py-20 px-6 max-w-[800px] mx-auto reveal">
                <div className="text-center mb-6 md:mb-12">
                    <h2 className="font-heading text-2xl md:text-3xl font-bold text-deep-navy mb-3">Pertanyaan Umum (FAQ)</h2>
                    <div className="section-divider" />
                    <p className="text-sm text-on-surface-variant mt-2">Menjawab hal-hal yang sering ditanyakan calon peserta.</p>
                </div>
                <div className="space-y-4">
                    {[
                        { q: 'Apakah sertifikat yang diterbitkan resmi?', a: 'Ya, seluruh sertifikat pelatihan diterbitkan langsung dan diakui secara resmi oleh Kementerian Ketenagakerjaan (KEMNAKER) RI atau Badan Nasional Sertifikasi Profesi (BNSP) sesuai jenis program yang dipilih.' },
                        { q: 'Di mana lokasi pelaksanaan training?', a: 'Pelatihan dapat diselenggarakan di gedung training center kami di Surabaya, maupun secara In-House (on-site) langsung di fasilitas operasional perusahaan Anda di seluruh wilayah Indonesia.' },
                        { q: 'Berapa jumlah minimal peserta untuk pelaksanaan training?', a: 'Untuk program publik minimal kuota bervariasi. Sedangkan untuk in-house training perusahaan, umumnya kami menyarankan minimal 5-10 peserta agar simulasi dan dinamika kelompok berjalan optimal, namun kami sangat fleksibel menyesuaikan kebutuhan Anda.' },
                        { q: 'Apakah materi training bisa disesuaikan dengan kebutuhan spesifik perusahaan?', a: 'Tentu. Kami menyediakan layanan kustomisasi kurikulum agar fokus studi kasus, jenis simulasi, dan jenis alat peraga relevan secara spesifik dengan risiko bahaya di tempat kerja Anda.' },
                        { q: 'Bagaimana sistem pembayaran pelatihan?', a: 'Pembayaran dapat dilakukan melalui transfer bank resmi perusahaan setelah penandatanganan penawaran/kontrak kerja sama, baik secara penuh di awal maupun termin yang disepakati.' },
                        { q: 'Apakah Pro Safe menyediakan training bersertifikasi internasional?', a: 'Ya, untuk program keselamatan maritim dan lepas pantai (offshore) tertentu, kami menawarkan sertifikasi berbasis lisensi regulator industri terkait.' }
                    ].map((faq, idx) => (
                        <div key={idx} className="bg-white rounded-2xl border border-outline-variant overflow-hidden transition-all duration-300">
                            <button
                                onClick={() => toggleFaq(idx)}
                                className="w-full px-6 py-5 flex items-center justify-between text-left font-heading font-bold text-deep-navy hover:text-safety-orange transition-colors"
                            >
                                <span>{faq.q}</span>
                                <span className={`material-symbols-outlined transition-transform duration-300 ${faqOpen === idx ? 'rotate-180 text-safety-orange' : 'text-outline'}`}>expand_more</span>
                            </button>
                            <div className={`transition-all duration-300 overflow-hidden ${faqOpen === idx ? 'max-h-48 border-t border-outline-variant/60' : 'max-h-0'}`}>
                                <p className="px-6 py-5 text-sm text-on-surface-variant leading-relaxed bg-surface-gray/50">{faq.a}</p>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Testimonials */}
            <section className="py-12 md:py-20 px-6 bg-surface-gray border-t border-outline-variant max-w-[1280px] mx-auto reveal">
                <div className="text-center mb-6 md:mb-12">
                    <h2 className="font-heading text-2xl md:text-3xl font-bold text-deep-navy mb-3">Apa Kata Klien Kami</h2>
                    <div className="section-divider" />
                    <p className="text-lg text-on-surface-variant">Testimoni dari profesional yang telah mempercayakan pelatihan K3 kepada kami.</p>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    {[
                        {
                            ...testimonials[0],
                            image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80'
                        },
                        {
                            ...testimonials[1],
                            image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=600&q=80'
                        },
                        {
                            ...testimonials[2],
                            image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80'
                        },
                        {
                            ...testimonials[3],
                            image: 'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=600&q=80'
                        }
                    ].map(t => (
                        <div key={t.id} className="relative aspect-[3/4] rounded-2xl overflow-hidden shadow-lg group hover:shadow-xl transition-all duration-300">
                            {/* Background Image */}
                            <img 
                                src={t.image} 
                                alt={t.name} 
                                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
                                loading="lazy"
                            />
                            {/* Overlay Gradient (Top-heavy and Bottom-heavy for text legibility) */}
                            <div className="absolute inset-0 bg-gradient-to-b from-black/85 via-black/35 to-black/90" />
                            
                            {/* Content */}
                            <div className="relative z-10 h-full flex flex-col justify-between p-6 text-center text-white">
                                {/* Top: Identity */}
                                <div>
                                    <h3 className="font-heading font-bold text-base tracking-wide">{t.name}</h3>
                                    <p className="text-[11px] text-white/70 mt-0.5">{t.role} at {t.company}</p>
                                </div>
                                
                                {/* Bottom: Stars & Testimonial */}
                                <div className="flex flex-col items-center">
                                    <div className="flex gap-0.5 mb-2.5">
                                        {Array.from({ length: t.rating }).map((_, i) => (
                                            <span key={i} className="material-symbols-outlined icon-fill text-safety-orange text-sm">star</span>
                                        ))}
                                    </div>
                                    <p className="text-[11px] sm:text-xs text-white/85 leading-relaxed font-light line-clamp-4">
                                        "{t.text}"
                                    </p>
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </section>

            {/* Artikel Terbaru */}
            <section className="py-12 md:py-20 px-6 max-w-[1280px] mx-auto reveal">
                <div className="text-center max-w-3xl mx-auto mb-6 md:mb-12">
                    <p className="text-safety-orange font-heading font-bold text-xs uppercase tracking-[0.2em] mb-2">Blog & Artikel</p>
                    <h2 className="font-heading text-2xl md:text-3xl lg:text-[2.1rem] font-bold text-deep-navy mb-3">Informasi & Edukasi K3 Terbaru</h2>
                    <div className="section-divider" />
                    <p className="text-base text-on-surface-variant mt-3">Rekomendasi bacaan penting seputar regulasi keselamatan kerja, sertifikasi K3, dan tips keamanan industri.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {blogPosts.slice(0, 3).map((post) => (
                        <Link 
                            key={post.id} 
                            href={`/blog`} 
                            className="group block bg-white rounded-2xl border border-outline-variant hover:border-deep-navy hover:shadow-lg transition-all overflow-hidden flex flex-col h-full"
                        >
                            <div className="relative h-52 overflow-hidden bg-slate-100 shrink-0">
                                <img 
                                    src={post.image} 
                                    alt={post.title} 
                                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
                                    loading="lazy"
                                />
                                <div className="absolute top-4 left-4 bg-safety-orange text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                                    {post.category}
                                </div>
                            </div>
                            <div className="p-6 flex flex-col flex-grow">
                                <span className="text-xs text-text-secondary font-medium mb-2 block">{post.date} · {post.readTime}</span>
                                <h3 className="font-heading text-base sm:text-lg font-bold text-deep-navy mb-3 group-hover:text-safety-orange transition-colors line-clamp-2">
                                    {post.title}
                                </h3>
                                <p className="text-xs text-on-surface-variant leading-relaxed line-clamp-3 mb-5 flex-grow">
                                    {post.excerpt}
                                </p>
                                <span className="inline-flex items-center text-safety-orange text-xs font-bold uppercase tracking-wider group-hover:translate-x-1.5 transition-transform duration-300">
                                    Baca Selengkapnya <span className="material-symbols-outlined text-sm ml-1">arrow_forward</span>
                                </span>
                            </div>
                        </Link>
                    ))}
                </div>
                <div className="mt-10 text-center">
                    <Link href="/blog" className="btn-prosafe-secondary text-sm px-8 py-3.5 shadow-sm">
                        Kunjungi Blog ProSafe
                    </Link>
                </div>
            </section>

            {/* Feed Instagram */}
            <section className="py-12 md:py-20 px-6 bg-surface-gray border-y border-outline-variant reveal">
                <div className="max-w-[1280px] mx-auto">
                    <div className="text-center max-w-3xl mx-auto mb-6 md:mb-12">
                        <p className="text-safety-orange font-heading font-bold text-xs uppercase tracking-[0.2em] mb-2">Galeri Instagram</p>
                        <h2 className="font-heading text-2xl md:text-3xl lg:text-[2.1rem] font-bold text-deep-navy mb-3">Ikuti Aktivitas Kami di Instagram</h2>
                        <div className="section-divider" />
                        <p className="text-base text-on-surface-variant mt-3">
                            Temukan dokumentasi pelatihan terbaru, info kelas, serta tips K3 menarik melalui akun resmi{' '}
                            <a 
                                href="https://www.instagram.com/prosafe_indonesia" 
                                target="_blank" 
                                rel="noopener noreferrer" 
                                className="text-safety-orange font-bold hover:underline"
                            >
                                @prosafe_indonesia
                            </a>.
                        </p>
                    </div>
                    <div className="elfsight-app-c11ba893-a933-4167-89ef-50d7b4f3c2b2" data-elfsight-app-lazy></div>
                </div>
            </section>

            {/* Inquiry Request Form */}
            <section className="py-12 md:py-20 px-6 max-w-[800px] mx-auto reveal">
                <div className="bg-white border border-outline-variant/70 rounded-2xl p-8 md:p-12 shadow-sm">
                    <div className="text-center mb-6 md:mb-8">
                        <h2 className="font-heading text-2xl md:text-3xl font-bold text-deep-navy mb-2">Hubungi Kami & Dapatkan Penawaran</h2>
                        <p className="text-sm text-on-surface-variant">Isi data di bawah ini, tim marketing kami akan segera menghubungi Anda dengan penawaran harga terbaik.</p>
                    </div>

                    {formSubmitted ? (
                        <div className="text-center py-8">
                            <div className="w-16 h-16 bg-wa-green/10 text-wa-green rounded-full flex items-center justify-center mx-auto mb-4">
                                <span className="material-symbols-outlined text-3xl">check_circle</span>
                            </div>
                            <h3 className="font-heading text-xl font-bold text-deep-navy mb-2">Permintaan Penawaran Terkirim</h3>
                            <p className="text-sm text-on-surface-variant mb-6">Terima kasih, admin kami akan segera menghubungi Anda kembali melalui WhatsApp atau email resmi.</p>
                            <button onClick={() => setFormSubmitted(false)} className="btn-prosafe-secondary text-sm px-6 py-2.5">
                                Kirim Form Lainnya
                            </button>
                        </div>
                    ) : (
                        <form onSubmit={(e) => { e.preventDefault(); setFormSubmitted(true); }} className="space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label htmlFor="nama_lengkap" className="block text-xs font-bold text-deep-navy uppercase tracking-wider mb-2">Nama Lengkap</label>
                                    <div className="input-prosafe-icon-wrapper">
                                        <span className="material-symbols-outlined">person</span>
                                        <input required type="text" id="nama_lengkap" name="nama" className="input-prosafe text-sm" placeholder="Contoh: Achmad Lutfi" />
                                    </div>
                                </div>
                                <div>
                                    <label htmlFor="whatsapp_number" className="block text-xs font-bold text-deep-navy uppercase tracking-wider mb-2">No. WhatsApp</label>
                                    <div className="input-prosafe-icon-wrapper">
                                        <span className="material-symbols-outlined">chat</span>
                                        <input required type="tel" id="whatsapp_number" name="whatsapp" className="input-prosafe text-sm" placeholder="Contoh: 081222998847" />
                                    </div>
                                </div>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label htmlFor="email_company" className="block text-xs font-bold text-deep-navy uppercase tracking-wider mb-2">Email Perusahaan</label>
                                    <div className="input-prosafe-icon-wrapper">
                                        <span className="material-symbols-outlined">mail</span>
                                        <input required type="email" id="email_company" name="email" className="input-prosafe text-sm" placeholder="Contoh: hrd@company.com" />
                                    </div>
                                </div>
                                <div>
                                    <label htmlFor="nama_perusahaan" className="block text-xs font-bold text-deep-navy uppercase tracking-wider mb-2">Nama Perusahaan</label>
                                    <div className="input-prosafe-icon-wrapper">
                                        <span className="material-symbols-outlined">business</span>
                                        <input required type="text" id="nama_perusahaan" name="company" className="input-prosafe text-sm" placeholder="Contoh: PT. Maju Bersama" />
                                    </div>
                                </div>
                            </div>
                            <div>
                                <label htmlFor="program_pilihan" className="block text-xs font-bold text-deep-navy uppercase tracking-wider mb-2">Program Pelatihan</label>
                                <CustomSelect
                                    value={selectedProgram}
                                    onChange={setSelectedProgram}
                                    placeholder="-- Pilih Program Pelatihan --"
                                    icon="school"
                                    required
                                    name="program"
                                    options={[
                                        { value: 'bfa', label: 'Basic First Aid (BFA)', sublabel: 'Pelatihan P3K Resmi Kemnaker RI / Sertifikat ProSafe' },
                                        { value: 'bff', label: 'Basic Fire Fighting (BFF)', sublabel: 'Pelatihan Penanggulangan Kebakaran Resmi Kemnaker RI' },
                                        { value: 'bbs', label: 'Safety Awareness (BBS)', sublabel: 'Behavior Based Safety & Budaya Keselamatan Kerja' },
                                        { value: 'sea_survival', label: 'Basic Sea Survival & HUET', sublabel: 'Sertifikasi Keselamatan Laut & Lepas Pantai K3 Migas' },
                                        { value: 'bosiet', label: 'BOSIET', sublabel: 'Basic Offshore Safety Induction & Emergency Training' },
                                        { value: 'other', label: 'Kebutuhan Custom Lainnya', sublabel: 'Program In-house Training & Konsultasi Spesifik Perusahaan' }
                                    ]}
                                />
                            </div>
                            <div>
                                <label htmlFor="keterangan_tambahan" className="block text-xs font-bold text-deep-navy uppercase tracking-wider mb-2">Keterangan Tambahan</label>
                                <div className="input-prosafe-icon-wrapper">
                                    <span className="material-symbols-outlined textarea-icon">edit_note</span>
                                    <textarea id="keterangan_tambahan" name="message" rows={4} className="input-prosafe text-sm resize-none" placeholder="Contoh: Estimasi jumlah peserta 15 orang, in-house training di Surabaya." />
                                </div>
                            </div>
                            <button type="submit" className="btn-prosafe-primary w-full justify-center py-4 text-base shadow-lg shadow-safety-orange/15 hover:shadow-safety-orange/30">
                                <span className="material-symbols-outlined">send</span> Kirim Permintaan Penawaran
                            </button>
                        </form>
                    )}
                </div>
            </section>
        </>
    );
}
