import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
const Controller980bb49ee7ae63891f1d891d2fbcf1c9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

Controller980bb49ee7ae63891f1d891d2fbcf1c9.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
Controller980bb49ee7ae63891f1d891d2fbcf1c9.url = (options?: RouteQueryOptions) => {
    return Controller980bb49ee7ae63891f1d891d2fbcf1c9.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
Controller980bb49ee7ae63891f1d891d2fbcf1c9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
Controller980bb49ee7ae63891f1d891d2fbcf1c9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
const Controller980bb49ee7ae63891f1d891d2fbcf1c9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
Controller980bb49ee7ae63891f1d891d2fbcf1c9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
Controller980bb49ee7ae63891f1d891d2fbcf1c9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controller980bb49ee7ae63891f1d891d2fbcf1c9.form = Controller980bb49ee7ae63891f1d891d2fbcf1c9Form
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
const Controller647e96047a8c0164cf05b0389bae6f94 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller647e96047a8c0164cf05b0389bae6f94.url(options),
    method: 'get',
})

Controller647e96047a8c0164cf05b0389bae6f94.definition = {
    methods: ["get","head"],
    url: '/jadwal',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
Controller647e96047a8c0164cf05b0389bae6f94.url = (options?: RouteQueryOptions) => {
    return Controller647e96047a8c0164cf05b0389bae6f94.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
Controller647e96047a8c0164cf05b0389bae6f94.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller647e96047a8c0164cf05b0389bae6f94.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
Controller647e96047a8c0164cf05b0389bae6f94.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller647e96047a8c0164cf05b0389bae6f94.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
const Controller647e96047a8c0164cf05b0389bae6f94Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller647e96047a8c0164cf05b0389bae6f94.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
Controller647e96047a8c0164cf05b0389bae6f94Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller647e96047a8c0164cf05b0389bae6f94.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
Controller647e96047a8c0164cf05b0389bae6f94Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller647e96047a8c0164cf05b0389bae6f94.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controller647e96047a8c0164cf05b0389bae6f94.form = Controller647e96047a8c0164cf05b0389bae6f94Form
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
const Controllercaa0ac59a54ac8054bbfb3b32db74b70 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllercaa0ac59a54ac8054bbfb3b32db74b70.url(options),
    method: 'get',
})

Controllercaa0ac59a54ac8054bbfb3b32db74b70.definition = {
    methods: ["get","head"],
    url: '/tentang-kami',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
Controllercaa0ac59a54ac8054bbfb3b32db74b70.url = (options?: RouteQueryOptions) => {
    return Controllercaa0ac59a54ac8054bbfb3b32db74b70.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
Controllercaa0ac59a54ac8054bbfb3b32db74b70.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllercaa0ac59a54ac8054bbfb3b32db74b70.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
Controllercaa0ac59a54ac8054bbfb3b32db74b70.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllercaa0ac59a54ac8054bbfb3b32db74b70.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
const Controllercaa0ac59a54ac8054bbfb3b32db74b70Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllercaa0ac59a54ac8054bbfb3b32db74b70.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
Controllercaa0ac59a54ac8054bbfb3b32db74b70Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllercaa0ac59a54ac8054bbfb3b32db74b70.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
Controllercaa0ac59a54ac8054bbfb3b32db74b70Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllercaa0ac59a54ac8054bbfb3b32db74b70.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controllercaa0ac59a54ac8054bbfb3b32db74b70.form = Controllercaa0ac59a54ac8054bbfb3b32db74b70Form
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
const Controller1c0fd81834b5d03d5839edc0710b74bb = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller1c0fd81834b5d03d5839edc0710b74bb.url(options),
    method: 'get',
})

Controller1c0fd81834b5d03d5839edc0710b74bb.definition = {
    methods: ["get","head"],
    url: '/corporate',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
Controller1c0fd81834b5d03d5839edc0710b74bb.url = (options?: RouteQueryOptions) => {
    return Controller1c0fd81834b5d03d5839edc0710b74bb.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
Controller1c0fd81834b5d03d5839edc0710b74bb.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller1c0fd81834b5d03d5839edc0710b74bb.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
Controller1c0fd81834b5d03d5839edc0710b74bb.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller1c0fd81834b5d03d5839edc0710b74bb.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
const Controller1c0fd81834b5d03d5839edc0710b74bbForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller1c0fd81834b5d03d5839edc0710b74bb.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
Controller1c0fd81834b5d03d5839edc0710b74bbForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller1c0fd81834b5d03d5839edc0710b74bb.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
Controller1c0fd81834b5d03d5839edc0710b74bbForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller1c0fd81834b5d03d5839edc0710b74bb.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controller1c0fd81834b5d03d5839edc0710b74bb.form = Controller1c0fd81834b5d03d5839edc0710b74bbForm
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
const Controller76dad08af968b2df31f85edec95da8a9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller76dad08af968b2df31f85edec95da8a9.url(options),
    method: 'get',
})

Controller76dad08af968b2df31f85edec95da8a9.definition = {
    methods: ["get","head"],
    url: '/kontak',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
Controller76dad08af968b2df31f85edec95da8a9.url = (options?: RouteQueryOptions) => {
    return Controller76dad08af968b2df31f85edec95da8a9.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
Controller76dad08af968b2df31f85edec95da8a9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller76dad08af968b2df31f85edec95da8a9.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
Controller76dad08af968b2df31f85edec95da8a9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller76dad08af968b2df31f85edec95da8a9.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
const Controller76dad08af968b2df31f85edec95da8a9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller76dad08af968b2df31f85edec95da8a9.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
Controller76dad08af968b2df31f85edec95da8a9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller76dad08af968b2df31f85edec95da8a9.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
Controller76dad08af968b2df31f85edec95da8a9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller76dad08af968b2df31f85edec95da8a9.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controller76dad08af968b2df31f85edec95da8a9.form = Controller76dad08af968b2df31f85edec95da8a9Form
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
const Controller0281689d11c3db12eb0f0bc21b3e4ed4 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller0281689d11c3db12eb0f0bc21b3e4ed4.url(options),
    method: 'get',
})

Controller0281689d11c3db12eb0f0bc21b3e4ed4.definition = {
    methods: ["get","head"],
    url: '/blog',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
Controller0281689d11c3db12eb0f0bc21b3e4ed4.url = (options?: RouteQueryOptions) => {
    return Controller0281689d11c3db12eb0f0bc21b3e4ed4.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
Controller0281689d11c3db12eb0f0bc21b3e4ed4.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller0281689d11c3db12eb0f0bc21b3e4ed4.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
Controller0281689d11c3db12eb0f0bc21b3e4ed4.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller0281689d11c3db12eb0f0bc21b3e4ed4.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
const Controller0281689d11c3db12eb0f0bc21b3e4ed4Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller0281689d11c3db12eb0f0bc21b3e4ed4.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
Controller0281689d11c3db12eb0f0bc21b3e4ed4Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller0281689d11c3db12eb0f0bc21b3e4ed4.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
Controller0281689d11c3db12eb0f0bc21b3e4ed4Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller0281689d11c3db12eb0f0bc21b3e4ed4.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controller0281689d11c3db12eb0f0bc21b3e4ed4.form = Controller0281689d11c3db12eb0f0bc21b3e4ed4Form
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
const Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927.url(options),
    method: 'get',
})

Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927.definition = {
    methods: ["get","head"],
    url: '/galeri',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927.url = (options?: RouteQueryOptions) => {
    return Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
const Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927.form = Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927Form
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
const Controller3cdbba6d669e09c30b4adcd8b1618770 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller3cdbba6d669e09c30b4adcd8b1618770.url(options),
    method: 'get',
})

Controller3cdbba6d669e09c30b4adcd8b1618770.definition = {
    methods: ["get","head"],
    url: '/testimoni',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
Controller3cdbba6d669e09c30b4adcd8b1618770.url = (options?: RouteQueryOptions) => {
    return Controller3cdbba6d669e09c30b4adcd8b1618770.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
Controller3cdbba6d669e09c30b4adcd8b1618770.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller3cdbba6d669e09c30b4adcd8b1618770.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
Controller3cdbba6d669e09c30b4adcd8b1618770.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller3cdbba6d669e09c30b4adcd8b1618770.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
const Controller3cdbba6d669e09c30b4adcd8b1618770Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller3cdbba6d669e09c30b4adcd8b1618770.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
Controller3cdbba6d669e09c30b4adcd8b1618770Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller3cdbba6d669e09c30b4adcd8b1618770.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
Controller3cdbba6d669e09c30b4adcd8b1618770Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller3cdbba6d669e09c30b4adcd8b1618770.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controller3cdbba6d669e09c30b4adcd8b1618770.form = Controller3cdbba6d669e09c30b4adcd8b1618770Form
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
const Controllere9c32bbc50ed76f81ae4c7e87f08b550 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllere9c32bbc50ed76f81ae4c7e87f08b550.url(options),
    method: 'get',
})

Controllere9c32bbc50ed76f81ae4c7e87f08b550.definition = {
    methods: ["get","head"],
    url: '/cabang',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
Controllere9c32bbc50ed76f81ae4c7e87f08b550.url = (options?: RouteQueryOptions) => {
    return Controllere9c32bbc50ed76f81ae4c7e87f08b550.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
Controllere9c32bbc50ed76f81ae4c7e87f08b550.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllere9c32bbc50ed76f81ae4c7e87f08b550.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
Controllere9c32bbc50ed76f81ae4c7e87f08b550.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllere9c32bbc50ed76f81ae4c7e87f08b550.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
const Controllere9c32bbc50ed76f81ae4c7e87f08b550Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllere9c32bbc50ed76f81ae4c7e87f08b550.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
Controllere9c32bbc50ed76f81ae4c7e87f08b550Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllere9c32bbc50ed76f81ae4c7e87f08b550.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
Controllere9c32bbc50ed76f81ae4c7e87f08b550Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllere9c32bbc50ed76f81ae4c7e87f08b550.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controllere9c32bbc50ed76f81ae4c7e87f08b550.form = Controllere9c32bbc50ed76f81ae4c7e87f08b550Form
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
const Controller0d9e669933993a5b35a625097409417b = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller0d9e669933993a5b35a625097409417b.url(options),
    method: 'get',
})

Controller0d9e669933993a5b35a625097409417b.definition = {
    methods: ["get","head"],
    url: '/cek-sertifikat',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
Controller0d9e669933993a5b35a625097409417b.url = (options?: RouteQueryOptions) => {
    return Controller0d9e669933993a5b35a625097409417b.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
Controller0d9e669933993a5b35a625097409417b.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller0d9e669933993a5b35a625097409417b.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
Controller0d9e669933993a5b35a625097409417b.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller0d9e669933993a5b35a625097409417b.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
const Controller0d9e669933993a5b35a625097409417bForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller0d9e669933993a5b35a625097409417b.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
Controller0d9e669933993a5b35a625097409417bForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller0d9e669933993a5b35a625097409417b.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
Controller0d9e669933993a5b35a625097409417bForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller0d9e669933993a5b35a625097409417b.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controller0d9e669933993a5b35a625097409417b.form = Controller0d9e669933993a5b35a625097409417bForm
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
const Controllerb46ef613ffe95eca299a3c89ce2c340c = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllerb46ef613ffe95eca299a3c89ce2c340c.url(options),
    method: 'get',
})

Controllerb46ef613ffe95eca299a3c89ce2c340c.definition = {
    methods: ["get","head"],
    url: '/karir',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
Controllerb46ef613ffe95eca299a3c89ce2c340c.url = (options?: RouteQueryOptions) => {
    return Controllerb46ef613ffe95eca299a3c89ce2c340c.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
Controllerb46ef613ffe95eca299a3c89ce2c340c.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllerb46ef613ffe95eca299a3c89ce2c340c.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
Controllerb46ef613ffe95eca299a3c89ce2c340c.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllerb46ef613ffe95eca299a3c89ce2c340c.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
const Controllerb46ef613ffe95eca299a3c89ce2c340cForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllerb46ef613ffe95eca299a3c89ce2c340c.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
Controllerb46ef613ffe95eca299a3c89ce2c340cForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllerb46ef613ffe95eca299a3c89ce2c340c.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
Controllerb46ef613ffe95eca299a3c89ce2c340cForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllerb46ef613ffe95eca299a3c89ce2c340c.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controllerb46ef613ffe95eca299a3c89ce2c340c.form = Controllerb46ef613ffe95eca299a3c89ce2c340cForm
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
const Controller8d420e8836099d9098a665641f2faef3 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller8d420e8836099d9098a665641f2faef3.url(options),
    method: 'get',
})

Controller8d420e8836099d9098a665641f2faef3.definition = {
    methods: ["get","head"],
    url: '/kebijakan-privasi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
Controller8d420e8836099d9098a665641f2faef3.url = (options?: RouteQueryOptions) => {
    return Controller8d420e8836099d9098a665641f2faef3.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
Controller8d420e8836099d9098a665641f2faef3.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller8d420e8836099d9098a665641f2faef3.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
Controller8d420e8836099d9098a665641f2faef3.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller8d420e8836099d9098a665641f2faef3.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
const Controller8d420e8836099d9098a665641f2faef3Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller8d420e8836099d9098a665641f2faef3.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
Controller8d420e8836099d9098a665641f2faef3Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller8d420e8836099d9098a665641f2faef3.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
Controller8d420e8836099d9098a665641f2faef3Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller8d420e8836099d9098a665641f2faef3.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controller8d420e8836099d9098a665641f2faef3.form = Controller8d420e8836099d9098a665641f2faef3Form
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
const Controller03293bd771fb203395c1b7dcfc34d6ff = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller03293bd771fb203395c1b7dcfc34d6ff.url(options),
    method: 'get',
})

Controller03293bd771fb203395c1b7dcfc34d6ff.definition = {
    methods: ["get","head"],
    url: '/syarat-ketentuan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
Controller03293bd771fb203395c1b7dcfc34d6ff.url = (options?: RouteQueryOptions) => {
    return Controller03293bd771fb203395c1b7dcfc34d6ff.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
Controller03293bd771fb203395c1b7dcfc34d6ff.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller03293bd771fb203395c1b7dcfc34d6ff.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
Controller03293bd771fb203395c1b7dcfc34d6ff.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller03293bd771fb203395c1b7dcfc34d6ff.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
const Controller03293bd771fb203395c1b7dcfc34d6ffForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller03293bd771fb203395c1b7dcfc34d6ff.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
Controller03293bd771fb203395c1b7dcfc34d6ffForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller03293bd771fb203395c1b7dcfc34d6ff.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
Controller03293bd771fb203395c1b7dcfc34d6ffForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller03293bd771fb203395c1b7dcfc34d6ff.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controller03293bd771fb203395c1b7dcfc34d6ff.form = Controller03293bd771fb203395c1b7dcfc34d6ffForm
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
const Controller4378cbca8999dfa15e68e73447704563 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller4378cbca8999dfa15e68e73447704563.url(options),
    method: 'get',
})

Controller4378cbca8999dfa15e68e73447704563.definition = {
    methods: ["get","head"],
    url: '/pendaftaran',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
Controller4378cbca8999dfa15e68e73447704563.url = (options?: RouteQueryOptions) => {
    return Controller4378cbca8999dfa15e68e73447704563.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
Controller4378cbca8999dfa15e68e73447704563.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller4378cbca8999dfa15e68e73447704563.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
Controller4378cbca8999dfa15e68e73447704563.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller4378cbca8999dfa15e68e73447704563.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
const Controller4378cbca8999dfa15e68e73447704563Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller4378cbca8999dfa15e68e73447704563.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
Controller4378cbca8999dfa15e68e73447704563Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller4378cbca8999dfa15e68e73447704563.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
Controller4378cbca8999dfa15e68e73447704563Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller4378cbca8999dfa15e68e73447704563.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controller4378cbca8999dfa15e68e73447704563.form = Controller4378cbca8999dfa15e68e73447704563Form
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
const Controller42a740574ecbfbac32f8cc353fc32db9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller42a740574ecbfbac32f8cc353fc32db9.url(options),
    method: 'get',
})

Controller42a740574ecbfbac32f8cc353fc32db9.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
Controller42a740574ecbfbac32f8cc353fc32db9.url = (options?: RouteQueryOptions) => {
    return Controller42a740574ecbfbac32f8cc353fc32db9.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
Controller42a740574ecbfbac32f8cc353fc32db9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller42a740574ecbfbac32f8cc353fc32db9.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
Controller42a740574ecbfbac32f8cc353fc32db9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller42a740574ecbfbac32f8cc353fc32db9.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
const Controller42a740574ecbfbac32f8cc353fc32db9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller42a740574ecbfbac32f8cc353fc32db9.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
Controller42a740574ecbfbac32f8cc353fc32db9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller42a740574ecbfbac32f8cc353fc32db9.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
Controller42a740574ecbfbac32f8cc353fc32db9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controller42a740574ecbfbac32f8cc353fc32db9.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controller42a740574ecbfbac32f8cc353fc32db9.form = Controller42a740574ecbfbac32f8cc353fc32db9Form
/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/settings/appearance'
*/
const Controllere19ee86e9cf603ce1a59a1ec5d21dec5 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url(options),
    method: 'get',
})

Controllere19ee86e9cf603ce1a59a1ec5d21dec5.definition = {
    methods: ["get","head"],
    url: '/settings/appearance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/settings/appearance'
*/
Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url = (options?: RouteQueryOptions) => {
    return Controllere19ee86e9cf603ce1a59a1ec5d21dec5.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/settings/appearance'
*/
Controllere19ee86e9cf603ce1a59a1ec5d21dec5.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/settings/appearance'
*/
Controllere19ee86e9cf603ce1a59a1ec5d21dec5.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/settings/appearance'
*/
const Controllere19ee86e9cf603ce1a59a1ec5d21dec5Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/settings/appearance'
*/
Controllere19ee86e9cf603ce1a59a1ec5d21dec5Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/settings/appearance'
*/
Controllere19ee86e9cf603ce1a59a1ec5d21dec5Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: Controllere19ee86e9cf603ce1a59a1ec5d21dec5.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

Controllere19ee86e9cf603ce1a59a1ec5d21dec5.form = Controllere19ee86e9cf603ce1a59a1ec5d21dec5Form

/**
* Multiple routes resolve to \Inertia\Controller::Controller, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `Controller['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
const Controller = {
    '/': Controller980bb49ee7ae63891f1d891d2fbcf1c9,
    '/jadwal': Controller647e96047a8c0164cf05b0389bae6f94,
    '/tentang-kami': Controllercaa0ac59a54ac8054bbfb3b32db74b70,
    '/corporate': Controller1c0fd81834b5d03d5839edc0710b74bb,
    '/kontak': Controller76dad08af968b2df31f85edec95da8a9,
    '/blog': Controller0281689d11c3db12eb0f0bc21b3e4ed4,
    '/galeri': Controllerf6d7c31aa90fe6c4f7bac34f2d5f9927,
    '/testimoni': Controller3cdbba6d669e09c30b4adcd8b1618770,
    '/cabang': Controllere9c32bbc50ed76f81ae4c7e87f08b550,
    '/cek-sertifikat': Controller0d9e669933993a5b35a625097409417b,
    '/karir': Controllerb46ef613ffe95eca299a3c89ce2c340c,
    '/kebijakan-privasi': Controller8d420e8836099d9098a665641f2faef3,
    '/syarat-ketentuan': Controller03293bd771fb203395c1b7dcfc34d6ff,
    '/pendaftaran': Controller4378cbca8999dfa15e68e73447704563,
    '/dashboard': Controller42a740574ecbfbac32f8cc353fc32db9,
    '/settings/appearance': Controllere19ee86e9cf603ce1a59a1ec5d21dec5,
}

export default Controller