import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../wayfinder'
/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
export const login = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

login.definition = {
    methods: ["get","head"],
    url: '/login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
login.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: login.url(options),
    method: 'get',
})

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
login.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: login.url(options),
    method: 'head',
})

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: login.url(options),
    method: 'get',
})

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
loginForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: login.url(options),
    method: 'get',
})

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::login
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:47
* @route '/login'
*/
loginForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: login.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

login.form = loginForm

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
* @route '/logout'
*/
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
* @route '/logout'
*/
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
* @route '/logout'
*/
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
* @route '/logout'
*/
const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: logout.url(options),
    method: 'post',
})

/**
* @see \Laravel\Fortify\Http\Controllers\AuthenticatedSessionController::logout
* @see vendor/laravel/fortify/src/Http/Controllers/AuthenticatedSessionController.php:100
* @route '/logout'
*/
logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
    action: logout.url(options),
    method: 'post',
})

logout.form = logoutForm

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
export const register = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

register.definition = {
    methods: ["get","head"],
    url: '/register',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
register.url = (options?: RouteQueryOptions) => {
    return register.definition.url + queryParams(options)
}

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
register.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: register.url(options),
    method: 'get',
})

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
register.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: register.url(options),
    method: 'head',
})

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
const registerForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: register.url(options),
    method: 'get',
})

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
registerForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: register.url(options),
    method: 'get',
})

/**
* @see \Laravel\Fortify\Http\Controllers\RegisteredUserController::register
* @see vendor/laravel/fortify/src/Http/Controllers/RegisteredUserController.php:41
* @route '/register'
*/
registerForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: register.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

register.form = registerForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/'
*/
homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: home.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

home.form = homeForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
export const jadwal = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: jadwal.url(options),
    method: 'get',
})

jadwal.definition = {
    methods: ["get","head"],
    url: '/jadwal',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
jadwal.url = (options?: RouteQueryOptions) => {
    return jadwal.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
jadwal.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: jadwal.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
jadwal.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: jadwal.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
const jadwalForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: jadwal.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
jadwalForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: jadwal.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/jadwal'
*/
jadwalForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: jadwal.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

jadwal.form = jadwalForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
export const tentangKami = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tentangKami.url(options),
    method: 'get',
})

tentangKami.definition = {
    methods: ["get","head"],
    url: '/tentang-kami',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
tentangKami.url = (options?: RouteQueryOptions) => {
    return tentangKami.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
tentangKami.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: tentangKami.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
tentangKami.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: tentangKami.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
const tentangKamiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: tentangKami.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
tentangKamiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: tentangKami.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/tentang-kami'
*/
tentangKamiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: tentangKami.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

tentangKami.form = tentangKamiForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
export const corporate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: corporate.url(options),
    method: 'get',
})

corporate.definition = {
    methods: ["get","head"],
    url: '/corporate',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
corporate.url = (options?: RouteQueryOptions) => {
    return corporate.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
corporate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: corporate.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
corporate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: corporate.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
const corporateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: corporate.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
corporateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: corporate.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/corporate'
*/
corporateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: corporate.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

corporate.form = corporateForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
export const kontak = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: kontak.url(options),
    method: 'get',
})

kontak.definition = {
    methods: ["get","head"],
    url: '/kontak',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
kontak.url = (options?: RouteQueryOptions) => {
    return kontak.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
kontak.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: kontak.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
kontak.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: kontak.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
const kontakForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: kontak.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
kontakForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: kontak.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kontak'
*/
kontakForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: kontak.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

kontak.form = kontakForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
export const blog = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: blog.url(options),
    method: 'get',
})

blog.definition = {
    methods: ["get","head"],
    url: '/blog',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
blog.url = (options?: RouteQueryOptions) => {
    return blog.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
blog.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: blog.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
blog.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: blog.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
const blogForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: blog.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
blogForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: blog.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/blog'
*/
blogForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: blog.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

blog.form = blogForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
export const galeri = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: galeri.url(options),
    method: 'get',
})

galeri.definition = {
    methods: ["get","head"],
    url: '/galeri',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
galeri.url = (options?: RouteQueryOptions) => {
    return galeri.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
galeri.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: galeri.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
galeri.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: galeri.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
const galeriForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: galeri.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
galeriForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: galeri.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/galeri'
*/
galeriForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: galeri.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

galeri.form = galeriForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
export const testimoni = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: testimoni.url(options),
    method: 'get',
})

testimoni.definition = {
    methods: ["get","head"],
    url: '/testimoni',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
testimoni.url = (options?: RouteQueryOptions) => {
    return testimoni.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
testimoni.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: testimoni.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
testimoni.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: testimoni.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
const testimoniForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: testimoni.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
testimoniForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: testimoni.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/testimoni'
*/
testimoniForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: testimoni.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

testimoni.form = testimoniForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
export const cabang = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cabang.url(options),
    method: 'get',
})

cabang.definition = {
    methods: ["get","head"],
    url: '/cabang',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
cabang.url = (options?: RouteQueryOptions) => {
    return cabang.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
cabang.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cabang.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
cabang.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cabang.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
const cabangForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cabang.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
cabangForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cabang.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cabang'
*/
cabangForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cabang.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

cabang.form = cabangForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
export const cekSertifikat = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cekSertifikat.url(options),
    method: 'get',
})

cekSertifikat.definition = {
    methods: ["get","head"],
    url: '/cek-sertifikat',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
cekSertifikat.url = (options?: RouteQueryOptions) => {
    return cekSertifikat.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
cekSertifikat.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: cekSertifikat.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
cekSertifikat.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: cekSertifikat.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
const cekSertifikatForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cekSertifikat.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
cekSertifikatForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cekSertifikat.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/cek-sertifikat'
*/
cekSertifikatForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: cekSertifikat.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

cekSertifikat.form = cekSertifikatForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
export const karir = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: karir.url(options),
    method: 'get',
})

karir.definition = {
    methods: ["get","head"],
    url: '/karir',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
karir.url = (options?: RouteQueryOptions) => {
    return karir.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
karir.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: karir.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
karir.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: karir.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
const karirForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: karir.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
karirForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: karir.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/karir'
*/
karirForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: karir.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

karir.form = karirForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
export const kebijakanPrivasi = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: kebijakanPrivasi.url(options),
    method: 'get',
})

kebijakanPrivasi.definition = {
    methods: ["get","head"],
    url: '/kebijakan-privasi',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
kebijakanPrivasi.url = (options?: RouteQueryOptions) => {
    return kebijakanPrivasi.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
kebijakanPrivasi.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: kebijakanPrivasi.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
kebijakanPrivasi.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: kebijakanPrivasi.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
const kebijakanPrivasiForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: kebijakanPrivasi.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
kebijakanPrivasiForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: kebijakanPrivasi.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/kebijakan-privasi'
*/
kebijakanPrivasiForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: kebijakanPrivasi.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

kebijakanPrivasi.form = kebijakanPrivasiForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
export const syaratKetentuan = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: syaratKetentuan.url(options),
    method: 'get',
})

syaratKetentuan.definition = {
    methods: ["get","head"],
    url: '/syarat-ketentuan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
syaratKetentuan.url = (options?: RouteQueryOptions) => {
    return syaratKetentuan.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
syaratKetentuan.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: syaratKetentuan.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
syaratKetentuan.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: syaratKetentuan.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
const syaratKetentuanForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: syaratKetentuan.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
syaratKetentuanForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: syaratKetentuan.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/syarat-ketentuan'
*/
syaratKetentuanForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: syaratKetentuan.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

syaratKetentuan.form = syaratKetentuanForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
export const pendaftaran = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pendaftaran.url(options),
    method: 'get',
})

pendaftaran.definition = {
    methods: ["get","head"],
    url: '/pendaftaran',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
pendaftaran.url = (options?: RouteQueryOptions) => {
    return pendaftaran.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
pendaftaran.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: pendaftaran.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
pendaftaran.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: pendaftaran.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
const pendaftaranForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pendaftaran.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
pendaftaranForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pendaftaran.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/pendaftaran'
*/
pendaftaranForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: pendaftaran.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

pendaftaran.form = pendaftaranForm

/**
* @see routes/web.php:24
* @route '/pelatihan/{category}'
*/
export const kategoriPelatihan = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: kategoriPelatihan.url(args, options),
    method: 'get',
})

kategoriPelatihan.definition = {
    methods: ["get","head"],
    url: '/pelatihan/{category}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:24
* @route '/pelatihan/{category}'
*/
kategoriPelatihan.url = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

    if (Array.isArray(args)) {
        args = {
            category: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        category: args.category,
    }

    return kategoriPelatihan.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:24
* @route '/pelatihan/{category}'
*/
kategoriPelatihan.get = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: kategoriPelatihan.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:24
* @route '/pelatihan/{category}'
*/
kategoriPelatihan.head = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: kategoriPelatihan.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:24
* @route '/pelatihan/{category}'
*/
const kategoriPelatihanForm = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: kategoriPelatihan.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:24
* @route '/pelatihan/{category}'
*/
kategoriPelatihanForm.get = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: kategoriPelatihan.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:24
* @route '/pelatihan/{category}'
*/
kategoriPelatihanForm.head = (args: { category: string | number } | [category: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: kategoriPelatihan.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

kategoriPelatihan.form = kategoriPelatihanForm

/**
* @see routes/web.php:29
* @route '/program/{slug}'
*/
export const detailProgram = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detailProgram.url(args, options),
    method: 'get',
})

detailProgram.definition = {
    methods: ["get","head"],
    url: '/program/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:29
* @route '/program/{slug}'
*/
detailProgram.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    if (Array.isArray(args)) {
        args = {
            slug: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        slug: args.slug,
    }

    return detailProgram.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:29
* @route '/program/{slug}'
*/
detailProgram.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detailProgram.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:29
* @route '/program/{slug}'
*/
detailProgram.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: detailProgram.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:29
* @route '/program/{slug}'
*/
const detailProgramForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: detailProgram.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:29
* @route '/program/{slug}'
*/
detailProgramForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: detailProgram.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:29
* @route '/program/{slug}'
*/
detailProgramForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: detailProgram.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

detailProgram.form = detailProgramForm

/**
* @see routes/web.php:34
* @route '/cabang/{city}'
*/
export const detailCabang = (args: { city: string | number } | [city: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detailCabang.url(args, options),
    method: 'get',
})

detailCabang.definition = {
    methods: ["get","head"],
    url: '/cabang/{city}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see routes/web.php:34
* @route '/cabang/{city}'
*/
detailCabang.url = (args: { city: string | number } | [city: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { city: args }
    }

    if (Array.isArray(args)) {
        args = {
            city: args[0],
        }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
        city: args.city,
    }

    return detailCabang.definition.url
            .replace('{city}', parsedArgs.city.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see routes/web.php:34
* @route '/cabang/{city}'
*/
detailCabang.get = (args: { city: string | number } | [city: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: detailCabang.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:34
* @route '/cabang/{city}'
*/
detailCabang.head = (args: { city: string | number } | [city: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: detailCabang.url(args, options),
    method: 'head',
})

/**
* @see routes/web.php:34
* @route '/cabang/{city}'
*/
const detailCabangForm = (args: { city: string | number } | [city: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: detailCabang.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:34
* @route '/cabang/{city}'
*/
detailCabangForm.get = (args: { city: string | number } | [city: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: detailCabang.url(args, options),
    method: 'get',
})

/**
* @see routes/web.php:34
* @route '/cabang/{city}'
*/
detailCabangForm.head = (args: { city: string | number } | [city: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: detailCabang.url(args, {
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

detailCabang.form = detailCabangForm

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url(options),
    method: 'get',
})

/**
* @see \Inertia\Controller::__invoke
* @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
* @route '/dashboard'
*/
dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
    action: dashboard.url({
        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
            _method: 'HEAD',
            ...(options?.query ?? options?.mergeQuery ?? {}),
        }
    }),
    method: 'get',
})

dashboard.form = dashboardForm
